#!/bin/bash
source ~/anaconda3/etc/profile.d/conda.sh #激活conda环境

colmap_res_txt="/home/yr/workspace/data/new_house3/100/colmapgs建图结果/sparse/0/images.txt"
gps_ned_ori="/home/yr/workspace/pycharm/scripts/test_sh/ori.xml"
video_gps_txt="/home/yr/workspace/data/new_house3/100/gps_info/FHY_gps.txt"
colmap2gnss_SRt_xml="/home/yr/workspace/data/new_house4/测试脚本文件夹/xml/srt.xml"

conda activate gaussian_splatting
python parse_colmap_map.py --colmap_res_txt $colmap_res_txt \
                          --gps_ned_ori $gps_ned_ori \
                          --video_gps_txt $video_gps_txt \
                          --colmap2gnss_SRt_xml $colmap2gnss_SRt_xml